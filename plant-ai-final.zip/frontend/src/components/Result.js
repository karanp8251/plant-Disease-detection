import React from "react";
import Chatbot from "./Chatbot";

function Result({data}){
  return(
    <div>
      <h2>{data.disease}</h2>
      <p>{(data.confidence*100).toFixed(2)}%</p>
      <p>{data.product.name} - ₹{data.product.price}</p>
      <Chatbot response={data.chatbot}/>
    </div>
  )
}
export default Result;
