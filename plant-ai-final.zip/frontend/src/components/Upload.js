import React, { useState } from "react";
import Result from "./Result";

function Upload(){
  const [image,setImage]=useState(null);
  const [data,setData]=useState(null);

  const upload=async()=>{
    const formData=new FormData();
    formData.append("file",image);

    const res=await fetch("http://localhost:8000/predict",{method:"POST",body:formData});
    const result=await res.json();
    setData(result);
  }

  return(
    <div>
      <input type="file" onChange={(e)=>setImage(e.target.files[0])}/>
      <button onClick={upload}>Detect</button>
      {data && <Result data={data}/>}
    </div>
  )
}
export default Upload;
