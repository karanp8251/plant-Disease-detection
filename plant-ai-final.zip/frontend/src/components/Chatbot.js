import React from "react";

function Chatbot({response}){
  return(
    <div style={{border:"1px solid gray",padding:10}}>
      <h3>AI Advisor</h3>
      <p>{response}</p>
    </div>
  )
}
export default Chatbot;
