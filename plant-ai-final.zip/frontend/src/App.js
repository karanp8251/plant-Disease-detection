import React from "react";
import Upload from "./components/Upload";

function App() {
  return (
    <div style={{padding:20}}>
      <h1>Plant Doctor AI</h1>
      <Upload />
    </div>
  );
}
export default App;
