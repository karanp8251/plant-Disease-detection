import requests

API_KEY = "YOUR_FREE_API_KEY"

def smart_chatbot(disease):
    prompt = f"You are an agriculture expert. Disease: {disease}. Give cause, pesticide, usage, prevention in Hindi + English."

    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": "mistral-7b-instruct",
        "messages": [{"role": "user", "content": prompt}]
    }

    response = requests.post(url, headers=headers, json=data)

    try:
        return response.json()['choices'][0]['message']['content']
    except:
        return "AI response error"
