from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image

from model import predict_disease
from products import products
from chatbot import smart_chatbot

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    img = Image.open(file.file)

    disease, confidence = predict_disease(img)
    product = products.get(disease, {})
    chatbot = smart_chatbot(disease)

    return {
        "disease": disease,
        "confidence": confidence,
        "product": product,
        "chatbot": chatbot
    }
