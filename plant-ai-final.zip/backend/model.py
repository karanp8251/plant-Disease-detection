import tensorflow as tf
import numpy as np
from PIL import Image

model = tf.keras.models.load_model("model.h5", compile=False)

classes = ["Leaf Blight", "Rust", "Healthy"]

def preprocess(img):
    img = img.resize((224,224))
    img = np.array(img)/255.0
    img = np.expand_dims(img, axis=0)
    return img

def predict_disease(img):
    processed = preprocess(img)
    pred = model.predict(processed)
    idx = int(np.argmax(pred))
    confidence = float(np.max(pred))
    return classes[idx], confidence
